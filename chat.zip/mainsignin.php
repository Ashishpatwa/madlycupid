<?php
session_start();
    ?>
    <META HTTP-EQUIV="Refresh" CONTENT="0; URL=http://localhost/search_engine/chat/htmlindex.php">
        <?php
?>