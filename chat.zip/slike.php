<?php
session_start();

// Set session variables


header('Location: htmlindex.php?slike=active');

?>