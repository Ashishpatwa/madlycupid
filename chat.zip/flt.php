<?php
session_start();
?>
<img src="<?=$_SESSION['pic']?>" id="blah" width="200" height="200" name="pic" border="2">