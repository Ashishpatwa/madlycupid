<?php
session_start();

// Set session variables


header('Location: htmlindex.php?fav=active');

?>