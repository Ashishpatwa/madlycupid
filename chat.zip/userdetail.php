<?php

include("db_connection.php");

$username = $_POST['name'];
$gender = $_POST['gender'];
$password = $_POST['password'];
$age = $_POST['age'];



?>