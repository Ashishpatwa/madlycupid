function userdetails()
{
    if(document.getElementById('userdetail').style.display=='block')
        {
        $('#userdetail').slideUp(100);
        }
        else
        {
        $('#userdetail').slideDown(100);
        }
    
}